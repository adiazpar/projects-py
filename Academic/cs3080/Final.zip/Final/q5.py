"""
CS3080 Final Exam
Name: Alejandro Diaz
Due Date: 12/11/23

Question 5 of the Final Exam:
"""

import functools


def lowercase(func):
    # Wrapper function to lowercase the input string:
    @functools.wraps(func)
    def wrapper(input):
        return func(input.lower())

    return wrapper


@lowercase
def printStr(str):
    print(str)


if __name__ == "__main__":
    hello = 'Hello WORLD!'
    printStr(hello)
