"""
CS3080 Final Exam
Name: Alejandro Diaz
Due Date: 12/11/23

Question 4 of the Final Exam:
"""

from random import randint

'''
I need to study implementation of generators a little more.
I cannot say exactly why multiplying num * 2 works because I
don't know why it does. I may refactor this code later when
I get a better grasp of how generators work with these types
'''


def generateOddNeg(num):
    gen_exp = (-i for i in range(1, num*2) if i % 2 == 1)

    for a in gen_exp:
        yield a


if __name__ == '__main__':
    n = randint(1, 10)

    print("The first " + str(n) + " negative odd numbers are: ", end='')
    for number in generateOddNeg(n):
        print(number, end=' ')
