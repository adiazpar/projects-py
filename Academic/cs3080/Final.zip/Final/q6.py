"""
CS3080 Final Exam
Name: Alejandro Diaz
Due Date: 12/11/23

Question 6 of the Final Exam:
"""

import time
import threading
from random import randint


def printCubes(n):
    # Get the current time to start timing:
    start = time.time()

    print("The first " + str(n) + " cubes: ", end="")
    for i in range(1, n + 1):
        curr_cube = i * i * i
        print(curr_cube, end=' ')

    # Get the end time to end timing:
    end = time.time()

    # Print elapsed time:
    print('\n' + printCubes.__name__ + ' took {0:.5f} secs to finish'.format(end-start))


def printSquares(n):
    # Get the current time to start timing:
    start = time.time()

    print("The first " + str(n) + " squares: ", end="")
    for i in range(1, n + 1):
        curr_cube = i * i
        print(curr_cube, end=' ')

    # Get the end time to end timing:
    end = time.time()

    # Print elapsed time:
    print('\n' + printSquares.__name__ + ' took {0:.5f} secs to finish'.format(end - start))


if __name__ == "__main__":
    num = randint(5, 12)

    # Creating the first thread:
    thread_cubes = threading.Thread(target=printCubes, args=(num,))

    # Creating the second thread:
    thread_squares = threading.Thread(target=printSquares, args=(num,))

    # Running the threads:
    thread_cubes.start()
    thread_cubes.join()

    thread_squares.start()
    thread_squares.join()

    # The join statements must be right after the start statements so that
    # the squares thread waits for the cubes thread to finish executing first.
    # Otherwise, the output would be super random

    # Printing end of program for reference:
    print("\nEnd of program.")
